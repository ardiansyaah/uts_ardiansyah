package com.example.uts_ardiansyah

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
